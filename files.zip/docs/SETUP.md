# Detailed Setup Guide

Complete step-by-step setup instructions for Mariah Magic Cold Calls.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Local Development Setup](#local-development-setup)
3. [Database Setup](#database-setup)
4. [API Keys Setup](#api-keys-setup)
5. [Deployment Setup](#deployment-setup)
6. [Verification](#verification)

## Prerequisites

### Required Software
- Node.js 18+ (https://nodejs.org)
- Git (https://git-scm.com)
- npm 9+ (comes with Node.js)

### System Requirements
- 4GB RAM minimum
- 500MB free disk space
- macOS, Linux, or Windows (WSL recommended)

### Accounts Required
- GitHub (https://github.com)
- Supabase (https://supabase.com)
- Google Cloud Console (https://console.cloud.google.com)
- Fly.io (https://fly.io)
- Vercel (https://vercel.com)

## Local Development Setup

### 1. Clone Repository

```bash
git clone https://github.com/ShaneM111/mariah-magic-cold-calls.git
cd mariah-magic-cold-calls