# 🚀 Mariah Magic Cold Calls

<div align="center">

![GitHub Actions CI](https://github.com/ShaneM111/mariah-magic-cold-calls/actions/workflows/backend-ci.yml/badge.svg)
![GitHub Actions Deploy](https://github.com/ShaneM111/mariah-magic-cold-calls/actions/workflows/backend-deploy.yml/badge.svg)
![Frontend Deploy](https://github.com/ShaneM111/mariah-magic-cold-calls/actions/workflows/frontend-deploy.yml/badge.svg)
![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Version: 1.0.0](https://img.shields.io/badge/version-1.0.0-green.svg)

**A production-ready telecom-focused cold-calling and appointment-setting platform for South African businesses.**

[Features](#features) • [Quick Start](#quick-start) • [Architecture](#architecture) • [Deployment](#deployment) • [Contributing](#contributing)

</div>

---

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Requirements](#requirements)
- [Quick Start](#quick-start)
  - [Local Development](#local-development)
  - [Environment Setup](#environment-setup)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [API Documentation](#api-documentation)
- [Deployment](#deployment)
  - [Backend Deployment](#backend-deployment-to-flyio)
  - [Frontend Deployment](#frontend-deployment-to-vercel)
- [Configuration](#configuration)
- [Database](#database)
- [Security & Compliance](#security--compliance)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)
- [License](#license)

---

## 🎯 Overview

**Mariah Magic Cold Calls** is a comprehensive platform for sales teams to manage cold-calling campaigns and appointment setting. Built for South African telecom businesses, it provides:

- 📊 **Lead Management** - Import and manage business leads via Google Places API
- ☎️ **Call Tracking** - Log calls with outcomes and notes
- 📅 **Appointment Scheduling** - Schedule and track appointments
- 👥 **Role-Based Access** - Admin, Manager, and Agent roles
- 📈 **Performance Analytics** - Track agent performance and call metrics
- ✅ **POPIA Compliant** - Meets South African data protection requirements
- 🔐 **Secure & Scalable** - JWT authentication, Supabase database, CDN delivery

### Key Benefits

✅ **No VoIP Required** - Agents dial from their phones, log calls in the app
✅ **Auto Lead Assignment** - Intelligent round-robin distribution
✅ **Google Places Integration** - Bulk import South African businesses
✅ **Real-Time Dashboards** - Manager overview of team performance
✅ **Mobile Responsive** - Works on desktop and mobile
✅ **Production Ready** - Fully tested, secured, and optimized

---

## ✨ Features

### Lead Management
- ✅ Create leads manually or import from Google Places API
- ✅ Filter by status (new, contacted, interested, appointment_scheduled)
- ✅ Assign leads to agents (auto or manual)
- ✅ Track last contact date
- ✅ Store company details and contact information

### Call Logging
- ✅ Log call outcomes (not_answered, voicemail, busy, connected, interested, not_interested)
- ✅ Record call duration
- ✅ Add call notes
- ✅ View call history per lead or agent
- ✅ Call statistics dashboard

### Appointment Management
- ✅ Schedule appointments with leads
- ✅ Track appointment status (scheduled, completed, cancelled, no_show)
- ✅ Add appointment notes
- ✅ Manager view of all appointments
- ✅ Agent calendar view

### Manager Dashboard
- ✅ Team performance overview
- ✅ Calls per agent metrics
- ✅ Appointments booked tracking
- ✅ Lead status breakdown
- ✅ Agent productivity insights

### Agent Dashboard
- ✅ Assigned leads overview
- ✅ Today's call summary
- ✅ Upcoming appointments
- ✅ Lead status distribution
- ✅ Quick call logging

### Security & Compliance
- ✅ JWT-based authentication
- ✅ Role-based access control (RBAC)
- ✅ POPIA-compliant data handling
- ✅ Data retention policies
- ✅ Secure password hashing (bcrypt)
- ✅ CORS protection
- ✅ Rate limiting ready

---

## 🛠️ Tech Stack

### Backend
- **Runtime:** Node.js 18+
- **Framework:** Express.js
- **Database:** PostgreSQL (Supabase)
- **Authentication:** JWT (jsonwebtoken)
- **Password Security:** bcryptjs
- **External APIs:** Google Places API
- **Logging:** Morgan + Custom Logger
- **Security:** Helmet, CORS, dotenv

### Frontend
- **Framework:** React 18
- **Build Tool:** Vite
- **Styling:** Tailwind CSS
- **Routing:** React Router v6
- **HTTP Client:** Axios
- **State Management:** React Context API
- **Icons:** Emoji (can be replaced with icon library)

### Deployment
- **Backend:** Fly.io
- **Frontend:** Vercel
- **Database:** Supabase
- **CI/CD:** GitHub Actions
- **Monitoring:** Built-in health checks

### Tools & Services
- **Version Control:** Git & GitHub
- **Package Manager:** npm
- **Dependency Management:** Dependabot
- **Code Quality:** ESLint, SonarQube
- **Security:** Snyk, TruffleHog
- **Testing:** Jest, Vitest

---

## 📦 Requirements

### System Requirements
- **Node.js:** 18.0.0 or higher
- **npm:** 9.0.0 or higher
- **Git:** 2.30.0 or higher

### External Services (Required)
- **Supabase Account** - https://supabase.com
- **Google Places API Key** - https://console.cloud.google.com
- **Fly.io Account** - https://fly.io (for backend)
- **Vercel Account** - https://vercel.com (for frontend)

### Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

---

## 🚀 Quick Start

### Local Development

#### 1. Clone the Repository

```bash
git clone https://github.com/ShaneM111/mariah-magic-cold-calls.git
cd mariah-magic-cold-calls