# GitHub Actions CI/CD Workflows

This document explains all the GitHub Actions workflows configured for Mariah Magic Cold Calls.

## Workflows Overview

### 1. **Backend CI** (`backend-ci.yml`)
**Trigger:** Push/PR to `main` or `develop` with changes in `backend/`

**Steps:**
- ✅ Install dependencies
- ✅ Run linter (ESLint)
- ✅ Run unit tests (Jest)
- ✅ Upload coverage to Codecov
- ✅ Build backend
- ✅ Security scan (Snyk)
- ✅ Dependency audit

**Secrets Required:**
- `SNYK_TOKEN` (optional)
- `SUPABASE_URL`
- `SUPABASE_KEY`

### 2. **Backend Deploy** (`backend-deploy.yml`)
**Trigger:** Push to `main` with changes in `backend/`

**Steps:**
- ✅ Deploy to Fly.io
- ✅ Health check
- ✅ Notify on success/failure

**Secrets Required:**
- `FLY_API_TOKEN` (Fly.io API token)

### 3. **Frontend CI** (`frontend-ci.yml`)
**Trigger:** Push/PR to `main` or `develop` with changes in `frontend/`

**Steps:**
- ✅ Install dependencies
- ✅ Run linter (ESLint)
- ✅ Run tests (Vitest/Jest)
- ✅ Build project
- ✅ Upload build artifacts
- ✅ Lighthouse performance audit

**Secrets Required:**
- `VITE_API_URL` (optional, uses default)

### 4. **Frontend Deploy** (`frontend-deploy.yml`)
**Trigger:** Push to `main` with changes in `frontend/`

**Steps:**
- ✅ Build with Vercel
- ✅ Deploy to Vercel
- ✅ Smoke tests
- ✅ Comment PR with deployment URL

**Secrets Required:**
- `VERCEL_TOKEN`
- `VERCEL_PROJECT_ID`
- `VERCEL_ORG_ID`

### 5. **Full Stack Integration Tests** (`full-stack-test.yml`)
**Trigger:** Push/PR to `main` or `develop`, daily schedule

**Steps:**
- ✅ Start backend server
- ✅ Start frontend dev server
- ✅ Run integration tests
- ✅ Test API endpoints
- ✅ Cleanup

### 6. **Security Scan** (`security-scan.yml`)
**Trigger:** Push/PR to `main` or `develop`, weekly schedule

**Steps:**
- ✅ Dependency audit (npm)
- ✅ Check for outdated packages
- ✅ SonarQube code quality scan
- ✅ TruffleHog secrets scan

**Secrets Required:**
- `SONAR_TOKEN` (optional)

### 7. **Code Review** (`code-review.yml`)
**Trigger:** Pull requests to `main` or `develop`

**Steps:**
- ✅ Check for large files
- ✅ Check commit message format
- ✅ Find TODO/FIXME comments
- ✅ Run linting
- ✅ Post review checklist

### 8. **Release** (`release.yml`)
**Trigger:** Push tag matching `v*` pattern

**Steps:**
- ✅ Build backend and frontend
- ✅ Create GitHub release
- ✅ Upload build artifacts

## Setting Up Secrets

### 1. Go to Repository Settings
GitHub → Settings → Secrets and variables → Actions

### 2. Add Required Secrets

#### Backend Secrets