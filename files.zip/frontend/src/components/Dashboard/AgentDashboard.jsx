import StatCard from './StatCard'

export default function AgentDashboard({ data }) {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome Back!</h1>
        <p className="text-gray-600">Here's your performance today</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          title="Total Leads"
          value={data.leads.total}
          icon="👥"
          color="blue"
        />
        <StatCard
          title="Today's Calls"
          value={data.today_calls.count}
          icon="☎️"
          color="purple"
        />
        <StatCard
          title="Call Duration"
          value={`${Math.round(data.today_calls.total_duration / 60)}m`}
          icon="⏱️"
          color="orange"
        />
        <StatCard
          title="Appointments"
          value={data.upcoming_appointments.length}
          icon="📅"
          color="green"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold mb-4">Lead Status Breakdown</h2>
          <div className="space-y-3">
            {Object.entries(data.leads.by_status).map(([status, count]) => (
              <div key={status} className="flex justify-between items-center">
                <span className="text-gray-600 capitalize">{status.replace('_', ' ')}</span>
                <span className="font-bold text-gray-900">{count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold mb-4">Upcoming Appointments</h2>
          {data.upcoming_appointments.length === 0 ? (
            <p className="text-gray-600 text-sm">No upcoming appointments</p>
          ) : (
            <div className="space-y-3">
              {data.upcoming_appointments.map(apt => (
                <div key={apt.id} className="pb-3 border-b border-gray-200 last:border-b-0">
                  <p className="font-medium text-gray-900">{apt.leads?.company_name}</p>
                  <p className="text-sm text-gray-600">
                    {new Date(apt.scheduled_datetime).toLocaleDateString()} at {new Date(apt.scheduled_datetime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}