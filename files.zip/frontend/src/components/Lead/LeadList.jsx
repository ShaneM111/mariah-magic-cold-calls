import { useState } from 'react'
import LeadCard from './LeadCard'

export default function LeadList({ leads, onRefresh }) {
  const [filterStatus, setFilterStatus] = useState('all')

  const filteredLeads = filterStatus === 'all' 
    ? leads 
    : leads.filter(lead => lead.status === filterStatus)

  const statusCounts = {
    new: leads.filter(l => l.status === 'new').length,
    contacted: leads.filter(l => l.status === 'contacted').length,
    interested: leads.filter(l => l.status === 'interested').length,
    appointment_scheduled: leads.filter(l => l.status === 'appointment_scheduled').length
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-3xl font-bold text-blue-600">{leads.length}</div>
          <div className="text-gray-600 text-sm">Total Leads</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-3xl font-bold text-gray-600">{statusCounts.new}</div>
          <div className="text-gray-600 text-sm">New</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-3xl font-bold text-purple-600">{statusCounts.interested}</div>
          <div className="text-gray-600 text-sm">Interested</div>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="text-3xl font-bold text-green-600">{statusCounts.appointment_scheduled}</div>
          <div className="text-gray-600 text-sm">Appointments</div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex gap-2 mb-6 overflow-x-auto">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition ${
              filterStatus === 'all'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            All ({leads.length})
          </button>
          <button
            onClick={() => setFilterStatus('new')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition ${
              filterStatus === 'new'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            New ({statusCounts.new})
          </button>
          <button
            onClick={() => setFilterStatus('interested')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition ${
              filterStatus === 'interested'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Interested ({statusCounts.interested})
          </button>
          <button
            onClick={() => setFilterStatus('appointment_scheduled')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition ${
              filterStatus === 'appointment_scheduled'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Appointments ({statusCounts.appointment_scheduled})
          </button>
        </div>

        {filteredLeads.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <p>No leads found</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredLeads.map(lead => (
              <LeadCard key={lead.id} lead={lead} onRefresh={onRefresh} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}