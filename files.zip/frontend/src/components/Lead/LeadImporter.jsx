import { useState } from 'react'

export default function LeadImporter({ onImport }) {
  const [searchQuery, setSearchQuery] = useState('')
  const [count, setCount] = useState(20)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    if (!searchQuery.trim()) {
      setError('Please enter a search query')
      return
    }

    setLoading(true)
    try {
      await onImport(searchQuery)
      setSuccess(`Successfully imported ${count} leads from Google Places`)
      setSearchQuery('')
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to import leads')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-3 bg-red-100 text-red-700 rounded text-sm">{error}</div>
      )}
      {success && (
        <div className="p-3 bg-green-100 text-green-700 rounded text-sm">{success}</div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Search Query (e.g. "IT Companies", "Restaurants")
          </label>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500"
            placeholder="Search in South Africa..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Number of leads
          </label>
          <select
            value={count}
            onChange={(e) => setCount(Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition"
      >
        {loading ? 'Importing...' : '📍 Import from Google Places'}
      </button>

      <p className="text-xs text-gray-500">
        ℹ️ Imports business listings from Google Places API for South Africa. Requires valid API key.
      </p>
    </form>
  )
}