import { useApi } from '../../hooks/useApi'
import { useState } from 'react'

export default function LeadCard({ lead, onRefresh }) {
  const { request } = useApi()
  const [showCallForm, setShowCallForm] = useState(false)
  const [callOutcome, setCallOutcome] = useState('connected')

  const handleLogCall = async (e) => {
    e.preventDefault()
    try {
      await request('POST', '/calls', {
        lead_id: lead.id,
        outcome: callOutcome,
        duration_seconds: 0,
        notes: ''
      })
      setShowCallForm(false)
      onRefresh()
    } catch (error) {
      console.error('Failed to log call:', error)
    }
  }

  const statusColors = {
    new: 'bg-gray-100 text-gray-800',
    contacted: 'bg-blue-100 text-blue-800',
    interested: 'bg-purple-100 text-purple-800',
    appointment_scheduled: 'bg-green-100 text-green-800'
  }

  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
      <div className="flex justify-between items-start mb-3">
        <div className="flex-1">
          <h3 className="font-bold text-gray-900">{lead.company_name}</h3>
          <p className="text-sm text-gray-600">{lead.phone}</p>
          {lead.email && <p className="text-sm text-gray-600">{lead.email}</p>}
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[lead.status] || 'bg-gray-100'}`}>
          {lead.status.replace('_', ' ')}
        </span>
      </div>

      {lead.address && (
        <p className="text-sm text-gray-500 mb-3">{lead.address}</p>
      )}

      <div className="flex gap-2">
        <button
          onClick={() => setShowCallForm(!showCallForm)}
          className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition"
        >
          Log Call
        </button>
        <button
          onClick={() => navigator.clipboard.writeText(lead.phone)}
          className="px-3 py-1 text-sm bg-gray-300 text-gray-700 rounded hover:bg-gray-400 transition"
        >
          Copy Phone
        </button>
      </div>

      {showCallForm && (
        <form onSubmit={handleLogCall} className="mt-4 p-4 bg-gray-50 rounded">
          <div className="mb-3">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Call Outcome
            </label>
            <select
              value={callOutcome}
              onChange={(e) => setCallOutcome(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500"
            >
              <option value="not_answered">Not Answered</option>
              <option value="voicemail">Voicemail</option>
              <option value="busy">Busy</option>
              <option value="connected">Connected</option>
              <option value="interested">Interested</option>
              <option value="not_interested">Not Interested</option>
            </select>
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              className="px-3 py-2 text-sm bg-green-600 text-white rounded hover:bg-green-700"
            >
              Save Call
            </button>
            <button
              type="button"
              onClick={() => setShowCallForm(false)}
              className="px-3 py-2 text-sm bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  )
}