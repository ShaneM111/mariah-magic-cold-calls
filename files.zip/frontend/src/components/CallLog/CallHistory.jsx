import { useState } from 'react'

export default function CallHistory({ calls, onRefresh }) {
  const [selectedOutcome, setSelectedOutcome] = useState('all')

  const filteredCalls = selectedOutcome === 'all'
    ? calls
    : calls.filter(call => call.outcome === selectedOutcome)

  const outcomeCounts = {
    not_answered: calls.filter(c => c.outcome === 'not_answered').length,
    voicemail: calls.filter(c => c.outcome === 'voicemail').length,
    busy: calls.filter(c => c.outcome === 'busy').length,
    connected: calls.filter(c => c.outcome === 'connected').length,
    interested: calls.filter(c => c.outcome === 'interested').length,
    not_interested: calls.filter(c => c.outcome === 'not_interested').length
  }

  const outcomeColors = {
    not_answered: 'bg-gray-100 text-gray-800',
    voicemail: 'bg-yellow-100 text-yellow-800',
    busy: 'bg-orange-100 text-orange-800',
    connected: 'bg-blue-100 text-blue-800',
    interested: 'bg-green-100 text-green-800',
    not_interested: 'bg-red-100 text-red-800'
  }

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Call Statistics</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {Object.entries(outcomeCounts).map(([outcome, count]) => (
            <div key={outcome} className="bg-gray-50 p-3 rounded">
              <div className="text-2xl font-bold text-gray-900">{count}</div>
              <div className="text-xs text-gray-600 capitalize">{outcome.replace('_', ' ')}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Call History</h2>
          <button
            onClick={onRefresh}
            className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Refresh
          </button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto">
          <button
            onClick={() => setSelectedOutcome('all')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition ${
              selectedOutcome === 'all'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            All ({calls.length})
          </button>
          {Object.entries(outcomeCounts).map(([outcome, count]) => (
            <button
              key={outcome}
              onClick={() => setSelectedOutcome(outcome)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition text-sm ${
                selectedOutcome === outcome
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {outcome.replace('_', ' ')} ({count})
            </button>
          ))}
        </div>

        {filteredCalls.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <p>No calls found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Date</th>
                  <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Phone</th>
                  <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Outcome</th>
                  <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Duration</th>
                  <th className="px-6 py-3 text-left text-sm font-medium text-gray-700">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredCalls.map(call => (
                  <tr key={call.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {new Date(call.call_date).toLocaleDateString()} {new Date(call.call_date).toLocaleTimeString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900 font-mono">{call.phone_number}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${outcomeColors[call.outcome]}`}>
                        {call.outcome.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {call.duration_seconds ? `${Math.round(call.duration_seconds / 60)}m` : '-'}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">{call.notes || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}