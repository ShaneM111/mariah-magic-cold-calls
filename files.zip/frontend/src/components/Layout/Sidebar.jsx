import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'

export default function Sidebar() {
  const location = useLocation()
  const { user } = useAuth()

  const menuItems = [
    { path: '/', label: 'Dashboard', icon: '📊' },
    { path: '/leads', label: 'Leads', icon: '👥' },
    { path: '/calls', label: 'Call Log', icon: '☎️' },
    { path: '/appointments', label: 'Appointments', icon: '📅' }
  ]

  const isActive = (path) => location.pathname === path

  return (
    <aside className="w-64 bg-gradient-to-b from-blue-900 to-blue-800 text-white p-6 hidden md:flex flex-col">
      <div className="mb-8">
        <h1 className="text-2xl font-bold">MM</h1>
        <p className="text-blue-200 text-xs">Cold Calls</p>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems.map(item => (
          <Link
            key={item.path}
            to={item.path}
            className={`px-4 py-3 rounded-lg transition flex items-center gap-3 ${
              isActive(item.path)
                ? 'bg-purple-600 text-white'
                : 'text-blue-200 hover:bg-blue-700'
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            {item.label}
          </Link>
        ))}
      </nav>

      <div className="border-t border-blue-700 pt-4">
        <p className="text-xs text-blue-300">
          Role: <span className="text-blue-100 font-medium capitalize">{user?.role}</span>
        </p>
      </div>
    </aside>
  )
}