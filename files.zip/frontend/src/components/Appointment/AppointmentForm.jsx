import { useState, useEffect } from 'react'
import { useApi } from '../../hooks/useApi'

export default function AppointmentForm({ onSubmit }) {
  const { request } = useApi()
  const [leads, setLeads] = useState([])
  const [formData, setFormData] = useState({
    lead_id: '',
    scheduled_date: '',
    scheduled_time: '',
    notes: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchLeads = async () => {
      try {
        const data = await request('GET', '/leads?status=interested')
        setLeads(data.leads)
      } catch (err) {
        console.error('Failed to fetch leads:', err)
      }
    }
    fetchLeads()
  }, [request])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (!formData.lead_id || !formData.scheduled_date || !formData.scheduled_time) {
      setError('All fields are required')
      return
    }

    setLoading(true)
    try {
      await onSubmit(formData)
      setFormData({ lead_id: '', scheduled_date: '', scheduled_time: '', notes: '' })
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to schedule appointment')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-3 bg-red-100 text-red-700 rounded text-sm">{error}</div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Lead *
          </label>
          <select
            name="lead_id"
            value={formData.lead_id}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500"
            required
          >
            <option value="">Select a lead...</option>
            {leads.map(lead => (
              <option key={lead.id} value={lead.id}>
                {lead.company_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date *
          </label>
          <input
            type="date"
            name="scheduled_date"
            value={formData.scheduled_date}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Time *
          </label>
          <input
            type="time"
            name="scheduled_time"
            value={formData.scheduled_time}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Notes
        </label>
        <textarea
          name="notes"
          value={formData.notes}
          onChange={handleChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-purple-500"
          placeholder="Appointment notes..."
          rows="3"
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition"
      >
        {loading ? 'Scheduling...' : 'Schedule Appointment'}
      </button>
    </form>
  )
}