import { useState } from 'react'

export default function AppointmentList({ appointments, onRefresh }) {
  const [selectedStatus, setSelectedStatus] = useState('scheduled')

  const filteredAppointments = appointments.filter(apt => apt.status === selectedStatus)

  const statusCounts = {
    scheduled: appointments.filter(a => a.status === 'scheduled').length,
    completed: appointments.filter(a => a.status === 'completed').length,
    cancelled: appointments.filter(a => a.status === 'cancelled').length,
    no_show: appointments.filter(a => a.status === 'no_show').length
  }

  const statusColors = {
    scheduled: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
    no_show: 'bg-orange-100 text-orange-800'
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Object.entries(statusCounts).map(([status, count]) => (
          <div key={status} className="bg-white p-4 rounded-lg shadow">
            <div className="text-2xl font-bold text-gray-900">{count}</div>
            <div className="text-sm text-gray-600 capitalize">{status}</div>
          </div>
        ))}
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Appointments</h2>
          <button
            onClick={onRefresh}
            className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Refresh
          </button>
        </div>

        <div className="flex gap-2 mb-6">
          {Object.entries(statusCounts).map(([status, count]) => (
            <button
              key={status}
              onClick={() => setSelectedStatus(status)}
              className={`px-4 py-2 rounded-lg transition text-sm capitalize ${
                selectedStatus === status
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {status} ({count})
            </button>
          ))}
        </div>

        {filteredAppointments.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <p>No appointments found</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredAppointments.map(apt => (
              <div key={apt.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-bold text-gray-900">{apt.leads?.company_name}</h3>
                    <p className="text-sm text-gray-600">{apt.leads?.phone}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium capitalize ${statusColors[apt.status]}`}>
                    {apt.status}
                  </span>
                </div>
                <div className="flex gap-4 text-sm text-gray-600 mb-3">
                  <span>📅 {new Date(apt.scheduled_datetime).toLocaleDateString()}</span>
                  <span>🕐 {new Date(apt.scheduled_datetime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                {apt.notes && <p className="text-sm text-gray-600 mb-3">Notes: {apt.notes}</p>}
                <div className="flex gap-2">
                  <button className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700">
                    Mark Complete
                  </button>
                  <button className="px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700">
                    Cancel
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}